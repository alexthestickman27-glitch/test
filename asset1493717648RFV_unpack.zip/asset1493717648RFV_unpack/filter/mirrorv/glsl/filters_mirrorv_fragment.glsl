
uniform sampler2D u_sTexture0;
uniform highp float u_reverse;
uniform highp float u_alpha;
uniform highp mat4 u_color_matrix;
varying highp vec2 v_v2TexCoord0;

void main()
{
	highp vec4 color;

	if(u_reverse > 0.0){

        if (v_v2TexCoord0.x < 0.5)
        	{
        		color = texture2D(u_sTexture0, vec2(1.0 - v_v2TexCoord0.x, v_v2TexCoord0.y)).bgra;
        	}
        	else
        	{
        		color = texture2D(u_sTexture0, v_v2TexCoord0).bgra;
        	}
    }
    else{

        if (v_v2TexCoord0.x > 0.5)
        {
            color = texture2D(u_sTexture0, vec2(1.0 - v_v2TexCoord0.x, v_v2TexCoord0.y)).bgra;
        }
        else
        {
            color = texture2D(u_sTexture0, v_v2TexCoord0).bgra;
        }
    }



	color = color * u_color_matrix;
	color = clamp(color, 0.0, 1.0);

	gl_FragColor =  color.bgra * u_alpha;
}